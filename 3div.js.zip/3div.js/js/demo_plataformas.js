// Tu codigo javaScript aqui..
        
        
        
        // Global var block..
        var ST = 0;
        // Global var assets..
        var ui = true;
        var loader0;
        var loader1;
        var loader2;
        var images = [];    // array de imagenes..
        var sounds = [];    // array de sonidos..
        var images_skybox = [];    // array de imagenes..
        var sky;
        var idPerso;
        var idJoy, b1,b2,b3;    // controles..
        var cam;
        var controls;
        //---------------------------------------------------------------------------------
        function event_jugar(){
            if(ui){
                ui = false;
                fadeOff(2000);
                sounds[6].play();
                gameController();
            }
        }
        //---------------------------------------------------------------------------------
        function event_opciones(){
            
        }
        //---------------------------------------------------------------------------------
        function event_creditos(){
            
        }
        //---------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------
        function main(){
            switch(ST){
                case 0:
                    fadingColor = "white";
                    backgroundClearColor = "black";
                    setMode(600, 360, false);
                    fadeOff(0);
                    //mouse.raycast = true;
                    setGravity(0,-1000,0);
                    loader0 = loadImages("data/demo_plataformas/image/");
                    loader1 = loadSounds("data/demo_plataformas/sound/",7);
                    loader2 = loadImages("data/demo_plataformas/skybox/", ".jpg");
                    // LIGHT..
                    ambientLight( 0xffffff, 0.5 );
                    ST = 10;
                    break;
                case 10:
                    if(loader0.ready && loader1.ready && loader2.ready){
                        images = loader0.get();
                        sounds = loader1.get();
                        images_skybox = loader2.get();
                        
                        sky = skyBox(images_skybox, 0);
                        sky.size = 800;
                        var b = gButton(images[1], width/2, 190, 0.4);
                        b.setEvent("event_jugar");
                        b = gButton(images[2], width/2, 240, 0.4);
                        b.setEvent("event_opciones");
                        b = gButton(images[3], width/2, 290, 0.4);
                        b.setEvent("event_creditos");
                        sounds[0].loop(true);
                        sounds[0].play();
                        
                        controls = new THREE.GamepadControls( camera );
                        
                        ST = 20;
                    }
                    break;
                case 20:
                    fadeOn(8000);
                    ST = 30;
                    break;
                case 30:
                    sky.angley += 0.1;
                    screenDrawGraphic(images[0], width/2, 80, 0, 0.7, 0.7, 255);
                    screenDrawText(null, 12, "3Div.js - 2019 - WebGl Game Programming Engine. The New Web Div Games Studio.", CENTER, width/2, 350, "white");
                    break;
                case 40:
                    // INGAME STATE..
                    //sky.angley = idPerso.x/10;
                    
                    break;
                    
                    
            }
        }
        //---------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------
        function onNetEvent(msg){
            console.log(msg);
        }
        //---------------------------------------------------------------------------------
        function event_b1(){
            sounds[7].play();
            if(idPerso.isOnGround() ){
                sounds[3].play();
                idPerso.flagSuelo = false;
                idPerso.addVy(30000);
                idPerso.addVy(30000);
            }
        }
        //---------------------------------------------------------------------------------
        function event_b2(){
            sounds[7].play();
            sounds[2].play();
            idPerso.brake(1000);
        }
        //---------------------------------------------------------------------------------
        function event_b3(){
            sounds[7].play();
        }
        //---------------------------------------------------------------------------------
        function gameController(){
            var p = new process();
            p.st = 0;
            p.frame = function(){
                switch(this.st){
                    case 0:
                        if(fading){
                            var act_vol = sounds[0].getVolume();
                            sounds[0].setVolume( act_vol * (1-alphaFading) );
                        }else{
                            sounds[0].stop();
                            letMeAlone();
                            this.st = 10;
                        }
                        break;
                    case 10:
                        sounds[1].loop(true);
                        sounds[1].play();
                        
                        idJoy = joystick(100,280, 200);
                        b1 = gButton(images[5], 400, 280);
                        b1.setEvent("event_b1");
                        b2 = gButton(images[6], 480, 280);
                        b2.setEvent("event_b2");
                        b3 = gButton(images[7], 560, 280);
                        b3.setEvent("event_b3");
                        
                        plano(0,-750,0);
                        idPerso = personaje(0,-700,0);
                        
                        for(var i=0; i<7; i++){
                            for(var j=0; j<10; j++){
                                var y = -750 + i*100;
                                var x = (int(random(10))-5) * 100;
                                var z = (int(random(10))-5) * 100;
                                plataforma(x,y,z);
                            }
                        }
                        
                        sky = skyBox(images_skybox, 0);
                        sky.size = 1500;
                        
                        fadeOn(1000);
                        ST = 40;
                        this.st = 20;
                        break;
                    case 20:
                        screenDrawText(null, 12, "3D world by Luis Lopez Martinez.", CENTER, width/2, 20, "white");
                        break;
                }
                
            }
            return p;
        }
        //---------------------------------------------------------------------------------
        function plano(x, y, z){
            var p = new process();
            p.x=x;p.y=y;p.z=z;
            p.initialize = function(){
                this.createMaterial(TEXTURED, images[4]);
                this.createPlane(1000, 1000);
                this.createBody(TYPE_PLANE);
            }
            p.frame = function(){
                
            }
            return p;
        }
        //---------------------------------------------------------------------------------
        function plataforma(x, y, z){
            var p = new process();
            p.x=x;p.y=y;p.z=z;
            p.initialize = function(){
                var randomColor = rgb( int(random(255)), int(random(255)), int(random(255)) );
                this.createMaterial(PHONG, randomColor);
                this.createBox(100, 10, 100);
                this.createBody(TYPE_BOX);
                this.setStatic(true);
            }
            p.frame = function(){
                
                var d = this.getDistance(idPerso);
                if(d>100){
                    this.alpha = 0.5;
                }else{
                    this.alpha = 1;
                }
                
                
                
            }
            return p;
        }
        //---------------------------------------------------------------------------------
        function personaje(x,y,z){
            var p = new process();
            p.st = 0;
            p.x = x;
            p.y = y;
            p.z = z;
            p.moving = false;
            p.flagSuelo = false;
            p.frame = function(){
                
                switch(this.st){
                    case 0:
                        this.createMaterial(FLAT, "red");
                        this.createSphere(30);
                        this.createBody(TYPE_SPHERE);
                        // CREAR LUZ dinamica QUE SIGUE AL PROCESO..
                        var luz = spotLight(this, 0xffffff, 0.6, 200, 180);
                        luz.setOffset(0, 100, 0);
                        this.addGroundControl();
                        this.st = 10;
                        break;
                    case 10:

                        this.moving = false;
                        
                        if(b3.active || key(_ENTER)){
                            controls.setAxis(idJoy.ax, idJoy.ay, 0, 0 );                // solo oriento la camara con los dos primeros axis..
                        }else{
                            if(idJoy.active){
                                
                                // el impulso necesario para mover al player en una direccion determinada partiendo de la orientación de la camara..
                                var pos = camera.position.clone();                      // posicion actual de la camara
                                controls.setAxis(0, 0, idJoy.ax, idJoy.ay );            // mover la camara con los segundos ejes..
                                var xx = camera.position.x - pos.x;                     // recojer diferencia de posicion..
                                var zz = camera.position.z - pos.z;                     // recojer diferencia de posicion..
                                
                                this.addVx(xx*7000);
                                this.addVz(zz*7000);
                                
                                //var impulse = new CANNON.Vec3( xx*7000, 0, zz*7000 );   // aplicar la diferencia como impulso..
                                //this.addImpulse(impulse);                               // aplicar la diferencia como impulso..
                                this.moving = true;
                                
                            }
                        }
                        
                        
                        if(this.moving===false && this.isOnGround()){
                            this.brake(200);
                        }
                        
                        if(this.y<-750){
                            this.body.position.set(0,-700,0);
                        }
                        break;
                }
                camera.position.set(this.x,this.y+50,this.z);
            }
            return p;
        }
        //---------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------