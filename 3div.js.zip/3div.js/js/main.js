// Global var block..
var ST = 0;
// Global var assets..
var loader;
var images = [];
var sounds = [];
var models = [];
var modelos = ['data/gltf/ferrari.glb',
               'data/gltf/Flamingo.glb',
               'data/gltf/Horse.glb',
               'data/gltf/LittlestTokyo.glb',
               'data/gltf/Parrot.glb',
               'data/gltf/PrimaryIonDrive.glb',
               'data/gltf/RobotExpressive.glb',
               'data/gltf/SimpleSkinning.gltf',
               'data/gltf/SittingBox.glb',
               'data/gltf/Soldier.glb',
               'data/gltf/Stork.glb',
              ];
var radio;
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function main(){
    switch(ST){

        case 0:
            setMode(1600, 1360, false);
            loader = loadModels(modelos);
            ST = 10;
            break;
        case 10:
            if(loader.ready){
                models = loader.get();
                personaje();
                ST = 20;
            }
            break;
        case 20:
            if(key(_LEFT)){
                camera.position.x -= 10;
            }
            if(key(_RIGHT)){
                camera.position.x += 10;
            }
            if(key(_UP)){
                camera.position.y += 10;
            }
            if(key(_DOWN)){
                camera.position.y -= 10;
            }
            if(key(_Q)){
                camera.position.z -= 10;
            }
            if(key(_A)){
                camera.position.z += 10;
            }
            break;
        case 30:
            
            break;
            
    }
}
//---------------------------------------------------------------------------------
function onNetEvent(msg){
    console.log(msg);
}
//---------------------------------------------------------------------------------
function personaje(){
    var p = new process();
    p.st = 0;
    p.a;
    p.b;
    p.frame = function(){
        switch(this.st){
            case 0:
                ambientLight("white", 1);
                this.addModel(models[6]);
                this.setModel(0);
                
                console.log("FINAL:",this.mesh);
                
                this.size = 50;
                this.angley = -90;
                this.z = -500;
                this.y = -60;
                
                // White directional light at half intensity shining from the top.
                var directionalLight = new THREE.DirectionalLight( 0xffffff, 0.5 );
                scene.add( directionalLight );
                
                this.st = 10;
                break;
            case 10:
                this.angley+=0.2;
                screenDrawText(null, 14, this.animationIsPlaying(), RIGHT, 10, 10, "white");
                if(key(_SPACE)){
                    this.animationStop();
                    this.animationReset();
                }
                if(!this.animationIsPlaying() && key(_1)){
                    this.animationSet(0);
                    this.animationReset();
                    this.animationPlay(1, false);
                }

                if(!this.animationIsPlaying() && key(_2)){
                    this.animationSet(1);
                    this.animationReset();
                    this.animationPlay(1, true);
                }
                
                if(!this.animationIsPlaying() && key(_3)){
                    this.animationSet(2);
                    this.animationReset();
                    this.animationPlay(1, false);
                }
                
                if(!this.animationIsPlaying() && key(_4)){
                    this.animationSet(3);
                    this.animationReset();
                    this.animationPlay(1, false);
                }
                
                if(!this.animationIsPlaying() && key(_5)){
                    this.animationSet(4);
                    this.animationReset();
                    this.animationPlay(1, false);
                }
                
                if(!this.animationIsPlaying() && key(_6)){
                    this.animationSet(5);
                    this.animationReset();
                    this.animationPlay(1, false);
                }
                
                if(!this.animationIsPlaying() && key(_7)){
                    this.animationSet(6);
                    this.animationReset();
                    this.animationPlay(1, false);
                }
                
                if(!this.animationIsPlaying() && key(_8)){
                    this.animationSet(7);
                    this.animationReset();
                    this.animationPlay(1, false);
                }
                
                break;
            case 20:
                
                break;
        }
    }
    
    return p;
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------





