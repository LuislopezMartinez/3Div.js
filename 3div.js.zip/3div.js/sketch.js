// Global var block..
var ST = 0;
// Global var assets..
var loader1, loader2;
var models = [];
var images = [];

var modelos =   [   "data/3d/corazon/corazon.obj", 
                    "data/3d/reloj/reloj.obj",
                    "data/3d/moneda/moneda.obj", 
                    "data/3d/bomba/durmiendo/bomba.obj",
                    "data/3d/bomba/agresiva/bomba.obj",
                    "data/3d/bomba/inchandose/bomba.obj",
                    "data/3d/enemigo_00/enemigo_00.obj",
                    "data/3d/ojo/ojo.obj",
                    "data/3d/raton/raton.obj",
                    "data/3d/portal/portal.obj",
                    "data/3d/pincho/pincho.obj",
                    "data/3d/bolaPinchos/bolaPinchos.obj",
                    "data/3d/bolaAmarilla/bolaAmarilla.obj",
                    "data/3d/lilicat/normal/lilicat.obj",
                    "data/3d/lilicat/danio/lilicat.obj",
                    "data/3d/lilicat/shock/lilicat.obj",
                    "data/3d/lilicat/horror/lilicat.obj",
                    "data/fbx/wolf/Wolf.fbx",
                ];


//---------------------------------------------------------------------------------
function main(){
    switch(ST){
        case 0:
            setMode(600, 360, false);
            new camara();
            mouse.raycast = true;
            loader1 = loadModels(modelos);
            loader2 = loadImages("data/image/");
            ST = 10;
            break;
        case 10:
            if(loader1.ready && loader2.ready){
                models = loader1.get();
                images = loader2.get();
                
                new cosa2d();
                new cosa3d();
                
                ST = 20;
            }
            break;
        case 20:
            
            break;
            
    }
}
//---------------------------------------------------------------------------------
function onNetEvent(msg){
    console.log(msg);
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function cosa2d(){
    var p = new process();
    p.st = 0;
    p.frame = function(){
        switch(this.st){
            case 0:
                this.setGraph(images[0]);
                this.size = 0.5;
                this.x = 140;
                this.y = height/2;
                this.st = 10;
                break;
            case 10:
                this.angle += 1;
                if(collisionMouse(this)){
                    screenDrawText(null, 22, "COLISION!", CENTER, this.x, 50,"red")
                }
                break;
        }
    }
    return p;
}
//---------------------------------------------------------------------------------
function cosa3d(){
    var p = new process();
    p.st = 0;
    p.frame = function(){
        switch(this.st){
            case 0:
                this.addModel(models[4]);
                this.setModel(0);
                this.size = 40;
                this.x = 60;
                this.st = 10;
                break;
            case 10:
                this.angley += 1;
                if(collisionMouse(this)){
                    var pos = this.worldToScreen();
                    screenDrawText(null, 22, "COLISION!", CENTER, pos.x, 50,"red")
                }
                break;
        }
    }
    return p;
}
//---------------------------------------------------------------------------------