// 3Div.js by Luis lopez martinez.

var img = [];
var snd = [];
var mod = [];

const PLANE         = 1;
const BOX           = 2;
const SPHERE        = 3;
const CYLINDER      = 4;
const CONE          = 5;
const TORUS         = 6;

const s_kill        = 7;

const FLAT          = 8;     // pixelart..
const SMOOTH        = 9;     // suavizado..
const WIRED         = 10;    // wire frame..
const DEPTH         = 11;    // iluminacion con profundidad.. mas lejos mas oscuro..
const PHONG         = 12;    // refleja luz dinamicamente..
const LAMBERT       = 13;    // no refleja luz dinamica..
const TEXTURED      = 14

const LEFT          = 15;
const RIGHT         = 16;
const CENTER        = 17;

const TYPE_BOX      = 18;
const TYPE_SPHERE   = 19;
const TYPE_PLANE    = 20;

var world;                  // mundo fisico de cannon.js..
var timeStep = 1/60;        // tiempo que dura un frame..

var _id_actual_process_runing_;
var unique_process_id_ = 0;
var _st_app_ = 0;
var mouse;
var processList = [];

var fps = 0;            // indica los frames reales por segundo..
var fps_counter = 0;    // contador de frames mientras no pasen 1000 milisegundos..
var fps_flag = false;   // se pone a true cuando pasan 1000 milisegundos..
var fps_time_start = 0; // marca el tiempo al inicio de la cuenta de frames..
var fps_time_now = 0;   // marca el tiempo actual..

var width;
var height;
var canvas;
var camera;
var scene;
var renderer;
var geometry;
var material;
var mesh;
var backgroundClearColor = 0x8f9fbf;

var canvas2d;
var ctx;

var fading = false;
var alphaFading = 0;
var deltaFading = 0;
var fadingColor = "white";
var fadingType  = 0;

var mouse;
var raycaster, raymouse = { x : 0, y : 0 };

var preloader_threejs = false;
var preloader_3Div_models = true;

var lockui = false;

var frameCount = 0;

var _clock_ = new THREE.Clock();    // reloj interno para animaciones..
var _delta_;                        // delta time del frame..

var _3div_socket;                   // puntero al socket de red..
const NET_TOK_DATA = '~';           // delimitier for socket tokens..

// Set the name of the hidden property and the change event for visibility
var hidden, visibilityChange; 
var _3div_fullscreen = false;

var _3div_reload_page_on_loss_focus_from_cache = false; // al minimazar y volver recarga la web desde el cache del explorador..
var _3div_reload_page_on_loss_focus_from_origin = false; // al minimizar y volver recarga la web descargandola de nuevo..

init();
animate();
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function requestFullScreen() {
    if(_3div_fullscreen){
        var el = document.body;

        // Supports most browsers and their versions.
        var requestMethod = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen;

        if (requestMethod) {

            // Native full screen.
            requestMethod.call(el);

        } else if (typeof window.ActiveXObject !== "undefined") {

            // Older IE.
            var wscript = new ActiveXObject("WScript.Shell");

            if (wscript !== null) {
                wscript.SendKeys("{F11}");
            }
        }
    }
}
//---------------------------------------------------------------------------------
function _fade_instantaneo_(){
    if (fadingType == -1) {
        deltaFading = 0;
        alphaFading = 0;
        fading = false;
    } else if (fadingType == 1) {
        deltaFading = 0;
        alphaFading = 1;
        fading = false;
    }
}
//---------------------------------------------------------------------------------
function fadeOn(time_) {
    fading = true;
    fadingType = -1;
    var fadingFramesLeft = Math.floor((time_ * 60) / 1000);
    deltaFading = (1.0 / fadingFramesLeft);
    if(time_ == 0){
        _fade_instantaneo_();
    }
    //console.log(fadingFramesLeft, deltaFading, alphaFading); 
}
//---------------------------------------------------------------------------------
function fadeOff(time_) {
    fading = true;
    fadingType = 1;
    var fadingFramesLeft = Math.floor((time_ * 60) / 1000);
    deltaFading = (1.0 / fadingFramesLeft);
    if(time_ == 0){
        _fade_instantaneo_();
    }
    //console.log(alphaFading, deltaFading, fading);
}
//---------------------------------------------------------------------------------
function initContext2D(){
    // look up the text canvas.
    canvas2d = document.getElementById("text");
    // make a 2D context for it
    ctx = canvas2d.getContext("2d");
}
//---------------------------------------------------------------------------------
function initTouch(){
    var el = document.getElementById("text");
    el.addEventListener("touchstart", handleStart, false);
    el.addEventListener("touchend", handleEnd, false);
    //el.addEventListener("touchcancel", handleCancel, false);
    //el.addEventListener("touchleave", handleLeave, false);
    el.addEventListener("touchmove", handleMove, false);
}
function handleStart(event) {
    //event.preventDefault();
    mouse.left = true;
    mouse.canvas_x = event.touches[0].clientX;
    mouse.canvas_y = event.touches[0].clientY;
    
    mouse.touches = event.touches;
    /*
    for (var i = 0; i < event.touches.length; i++) {
        var touch = event.touches[i];
        mouse.touches = event.touches;
    }
    */
    
}
function handleEnd(event) {
    //event.preventDefault();
    mouse.left = false;
    
    mouse.touches = event.touches;
    
}
function handleMove(event) {
    //event.preventDefault();
    mouse.canvas_x = event.touches[0].clientX;
    mouse.canvas_y = event.touches[0].clientY;
    
    mouse.touches = event.touches;
    
}


//---------------------------------------------------------------------------------
function initPreloaderEvents(){
    THREE.DefaultLoadingManager.onStart = function ( url, itemsLoaded, itemsTotal ) {
        //console.log( 'Started loading file: ' + url + '.\nLoaded ' + itemsLoaded + ' of ' + itemsTotal + ' files.' );
    };

    THREE.DefaultLoadingManager.onLoad = function ( ) {
        //console.log( 'Loading Complete!');
    };


    THREE.DefaultLoadingManager.onProgress = function ( url, itemsLoaded, itemsTotal ) {
        //console.log( 'Loading file: ' + url + '.\nLoaded ' + itemsLoaded + ' of ' + itemsTotal + ' files.' );
    };

    THREE.DefaultLoadingManager.onError = function ( url ) {
        console.log( 'There was an error loading ' + url );
    };
}
//---------------------------------------------------------------------------------
function openSocket(server, port){
    // Crea el socket..
    _3div_socket = new WebSocket(server+':'+port);
    _3div_socket.status = 0;
    // Abre la conexión
    _3div_socket.addEventListener('open', function (event) {
        //_3div_socket.send("Hello World!");
        _3div_socket.status = 1;
        console.log("WebSocket conected to: ", event.target.url);
    });
            
    _3div_socket.addEventListener('message', function (event) {
        //console.log(event);
        onNetEvent( event.data.split(NET_TOK_DATA) );
        
        
    });
            
    _3div_socket.addEventListener('error', function (event) {
        _3div_socket.status = 2;
        console.log("WebSocket lost connecton.");
    });
            
    _3div_socket.addEventListener('close', function (event) {
        _3div_socket.status = 3;
        console.log("WebSocket connection clossed.");
    });
    return _3div_socket;
}
//---------------------------------------------------------------------------------
function netMessage(){
    this.NET_TOK_DATA = '~';    // delimitier for datagram tokens..
    this.buffer = '';
    this.add = function (token){
        if(this.buffer===''){
            this.buffer += token;
        }else{
            this.buffer += this.NET_TOK_DATA + token;
        }
    }
    this.send = function (){
        _3div_socket.send(this.buffer);
    }
}
//---------------------------------------------------------------------------------
function initVisibilityPage(){
    if (typeof document.hidden !== "undefined") { // Opera 12.10 and Firefox 18 and later support 
  hidden = "hidden";
  visibilityChange = "visibilitychange";
} else if (typeof document.msHidden !== "undefined") {
  hidden = "msHidden";
  visibilityChange = "msvisibilitychange";
} else if (typeof document.webkitHidden !== "undefined") {
  hidden = "webkitHidden";
  visibilityChange = "webkitvisibilitychange";
}
}


// If the page is hidden, pause the video;
// if the page is shown, play the video
function handleVisibilityChange() {
    if (document[hidden]) {
        //_3div_pause();
    }else{
        //_3div_play();
        if(_3div_reload_page_on_loss_focus_from_cache){
            window.location.reload(false);
        }else if(_3div_reload_page_on_loss_focus_from_cache){
            window.location.reload(true);
        }
    }
}


// Warn if the browser doesn't support addEventListener or the Page Visibility API
if (typeof document.addEventListener === "undefined" || hidden === undefined) {
  console.log("This demo requires a browser, such as Google Chrome or Firefox, that supports the Page Visibility API.");
} else {
  // Handle page visibility change   
  document.addEventListener(visibilityChange, handleVisibilityChange, false);
    
  // When the video pauses, set the title.
  // This shows the paused
  document.addEventListener("pause", function(){
    document.title = 'Paused';
  }, false);
    
  // When the video plays, set the title.
  document.addEventListener("play", function(){
    document.title = 'Playing'; 
  }, false);

}

//---------------------------------------------------------------------------------
function init3d(){
    // LIGHT..
    var ambientLight = new THREE.AmbientLight( 0xffffff, 0.9 );
    scene.add( ambientLight );
    var directionalLight = new THREE.DirectionalLight( 0xffeedd, 0.5 );
    directionalLight.position.set( 0, 1, 0 ).normalize();
    scene.add( directionalLight );
    // FOG..
    const near = 10;
    const far = 300;
    const color = 0x1010ff;
    scene.fog = new THREE.Fog(color, near, far);
}
//---------------------------------------------------------------------------------
var upVector = new CANNON.Vec3(0, 1, 0);
var contactNormal = new CANNON.Vec3(0, 0, 0);
var _3div_requestIsGrounded = [];
//---------------------------------------------------------------------------------
function initCannon() {

    world = new CANNON.World();
    world.gravity.set(0,0,0);
    world.broadphase = new CANNON.NaiveBroadphase();
    world.solver.iterations = 10;
    
    world.addEventListener("preStep", function(e) {
        for(var i=0; i<world.bodies.length; i++){
            world.bodies[i].isOnGround = false;
        }
    });
    
    world.addEventListener("postStep", function(e) {
        if(world.contacts.length > 0) {
            for(var i = 0; i < world.contacts.length; i++) {
                var contact = world.contacts[i];
                for(var j=0; j<_3div_requestIsGrounded.length; j++){
                    var object = _3div_requestIsGrounded[j];
                    if(contact.bi.id == object.id || contact.bj.id == object.id) {
                        if(contact.bi.id == object.id) {
                            contact.ni.negate(contactNormal);
                        } else {
                            contact.ni.copy(contactNormal);
                        }
                            object.isOnGround = contactNormal.dot(upVector) > 0.5;
                    }
                }
            }
        }
    });
}
//---------------------------------------------------------------------------------
function setGravity(x, y, z){
    world.gravity.set(x, y, z);
}
//---------------------------------------------------------------------------------
function init(){
    camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 1, 1000);
    camera.position.set(0, 0, 0);
    scene = new THREE.Scene();
    scene.add(camera);
    
    canvas = document.querySelector('#c');
    canvas.width = 320;
    canvas.height = 200;
    renderer = new THREE.WebGLRenderer({canvas});
    //renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setClearColor(backgroundClearColor, 1);
    document.body.appendChild(renderer.domElement);
    
    initContext2D();
    
    Waud.init();
    //Waud.autoMute();
    
    initTouch();
    
    initPreloaderEvents();
    
    //init3d();
    
    initVisibilityPage();
    
    mouse = new Mouse();
    raycaster = new THREE.Raycaster();
    
    initCannon();
    
}
//---------------------------------------------------------------------------------
function animate() {
    requestAnimationFrame(animate);
    _delta_ = _clock_.getDelta();
    switch(_st_app_){
        case 0:
            
            _st_app_ = 10;
            
            break;
        case 10:        
            // MOUSE INTERFACE..
            mouse.frame();
            //raycast();
            
            
            // CLEAR CANVAS2D..
            ctx.clearRect(0, 0, canvas2d.width, canvas2d.height);
            
            // MAIN LOOP..
            _id_actual_process_runing_ = null;
            if(frameCount>1){
                main();
            }
            
            // SORT SPRITE SET..
            processList.sort(function (a, b) {
                return a.priority - b.priority;
            });
            
            
            // EXECUTE SPRITE BATCH OPERATIONS..
            for(var i=0; i<processList.length; i++){
                if (processList[i].statusKill) {
                    processList[i].finalize();
                    
                    processList.splice(i, 1);        // elimino el proceso de la lista..
                }else if (!processList[i].live) {
                    processList[i].statusKill = true;
                }
            }
            
            
            
            for(var i=0; i<processList.length; i++){
                
                _id_actual_process_runing_ = processList[i];
                
                if(_id_actual_process_runing_.livedFrames==0){
                    _id_actual_process_runing_.initialize();
                }
                _id_actual_process_runing_.livedFrames++;
                
                if(_id_actual_process_runing_.live){
                    // DRAW SPRITE GRAPH..
                    processList[i].draw();
                    // EXECUTE SPRITE CODE..
                    processList[i].frame();
                    
                    // RESET RAYCAST COLLISION MOUSE DETECTION..
                    if(processList[i].model){
                        processList[i].mouseover = false;
                    }
                }
                
            }
            
            
            if(world){
                world.step(timeStep);
            }
            
            
            renderer.render(scene, camera);
            
            
            if (fading) {
                if (fadingType == -1) {
                    if (alphaFading > 0.0) {
                        alphaFading -= deltaFading;
                    } else {
                        deltaFading = 1.0;
                        alphaFading = 0.0;
                        fading = false;
                    }
                } else if (fadingType == 1) {
                    if (alphaFading < 1.0) {
                        alphaFading += deltaFading;
                    } else {
                        deltaFading = 0;
                        alphaFading = 1.0;
                        fading = false;
                    }
                }
            }
            
            if(alphaFading > 0){ 
                ctx.save();
                ctx.globalAlpha=alphaFading;
                ctx.fillStyle = fadingColor;
                ctx.fillRect(0, 0, width, height);
                ctx.restore();
            }
            
            frameCount++;
            
            break;
    }
    
    
    if(fps_flag){
        fps_counter++;
        fps_time_now = Date.now();
        if((fps_time_now-fps_time_start)>1000){
            fps_flag = false;
        }
    }else{
        fps = fps_counter;
        fps_counter = 0;
        fps_time_start = Date.now();
        fps_flag = true;
    }
    
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function setMode(width_, height_, fullscreen) {
    _3div_fullscreen = fullscreen;
    width = width_;
    height = height_;
    canvas.width = canvas2d.width = width_;
    canvas.height = canvas2d.height = height_;
    renderer = new THREE.WebGLRenderer({canvas});
    renderer.setClearColor(backgroundClearColor, 1);
}
//---------------------------------------------------------------------------------
function setFps(fps_){
    
}
//---------------------------------------------------------------------------------
function exists(proc){
    if(proc===undefined){
        return false;
    }
    if(proc.live){
        return true;
    }else{
        return false;
    }
    //return false;
}
//---------------------------------------------------------------------------------
function signal (id, sig){
    switch(sig){
        case s_kill:
            id.live = false;
        break;
    }
}
//---------------------------------------------------------------------------------
function letMeAlone() {
    for (var i=0; i<processList.length; i++) {
        if(!processList[i].killProtection){
            if(processList[i] != _id_actual_process_runing_ ){
                processList[i].live = false;
            }
        }
    }
}
//---------------------------------------------------------------------------------
//following two rotation functions are updated versions of code from: https://github.com/mrdoob/three.js/issues/1219
//updated to work in latest versions (r52 tested) of THREE.js

// Rotate an object around an axis in object space
var rotationMatrix;

    function rotateAroundObjectAxis( object, axis, radians_ ) {
    rotationMatrix = new THREE.Matrix4();
    rotationMatrix.makeRotationAxis( axis.normalize(), radians_ );
    object.matrix.multiplySelf( rotationMatrix );                       // post-multiply
    object.rotation.setEulerFromRotationMatrix(object.matrix, object.order);
}

// Rotate an object around an axis in world space (the axis passes through the object's position) 
var rotWorldMatrix;      
function rotateAroundWorldAxis( object, axis, radians ) {
    rotWorldMatrix = new THREE.Matrix4();
    rotWorldMatrix.makeRotationAxis(axis.normalize(), radians);
    rotWorldMatrix.multiplySelf(object.matrix);        // pre-multiply
    object.matrix = rotWorldMatrix;
    object.rotation.setEulerFromRotationMatrix(object.matrix, object.order);
} 
//---------------------------------------------------------------------------------
function process() {
    this.statusKill = false;
    this.priority = 512;
    this.visible = true;
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.angle = 0;     // angulo modificable desde el proceso..
    this.anglex = 0;    // angulo modificable desde el proceso..
    this.angley = 0;    // angulo modificable desde el proceso..
    this.size = 1.0;
    this.sizex = 1;
    this.sizey = 1;
    this.sizez = 1;
    this.alpha = 1.0;
    this.model   = false;
    this.graphic = false;
    this.primitive3d = false;
    this.geometry;                  // objeto 3d..
    this.material;                  // material del objeto 3d..
    this.mesh;                      // geometry + material = model..
    this.models = [];               // Array de modelos para el proceso..
    this.model_index = 0;           // numero de modelo activo..
    this.animation_mixer;           // mezclador para animaciones 3d..
    this.live = true;
    this.killProtection = false;
    this.cx = 0;
    this.cy = 0;
    processList.push(this);
    this.father = _id_actual_process_runing_;
    unique_process_id_++;
    this.id = unique_process_id_;   // id del proceso.. int..
    this.mouseover = false;         // si el proceso tiene un modelo 3d.. esto se pone a true si el mouse colisiona..
    this.mouseover_distance = 0;    // complementa al anterior..
    this.livedFrames = 0;
    this.physic = false;            // indica si la fisica esta activa en este proceso..
    this.body;                      // cuerpo fisico del proceso..
    this.radius = 0;                // si creas cuerpos esfericos guardan aquí su radio..
    this.oldMass = 0;               // cuando haces estatico un cuerpo guardas aquí su masa                                      anterior, para volver a dinamico cuando quieras..
    
    
    this.initialize = function(){
        
    }
    //---------------------------------------------------------
    this.draw = function (){        
        
        if(this.model){
            this.mesh.visible = this.visible;
            this.mesh.position.set(this.x, this.y, this.z);
            if(this.sizex!=1 || this.sizey!=1 || this.sizez!=1){
                this.mesh.scale.x = this.sizex;
                this.mesh.scale.y = this.sizey;
                this.mesh.scale.z = this.sizez;
            }else{
                this.mesh.scale.x = this.size;
                this.mesh.scale.y = this.size;
                this.mesh.scale.z = this.size;
            }
            
            if(this.physic){
                
                this.mesh.quaternion.copy(this.body.quaternion);
                this.mesh.position.copy(this.body.position);
                this.angle  = this.body.quaternion.z;
                this.anglex = this.body.quaternion.x;
                this.angley = this.body.quaternion.y;
                
            }else{
                
                this.mesh.rotation.set(radians(this.anglex), radians(this.angley), radians(this.angle));
                
                if(this.animation_mixer){this.animation_mixer.update(_delta_);}
                
            }
            
        }
        
        if(this.graphic){
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(radians(-this.angle));
            ctx.globalAlpha=this.alpha;
            if(this.visible){
                if(this.sizex!=1 || this.sizey!=1){
                    ctx.drawImage(this.graph, this.cx*this.sizex, this.cy*this.sizey, this.graph.width*this.sizex, this.graph.height*this.sizey);
                }else{
                    ctx.drawImage(this.graph, this.cx*this.size, this.cy*this.size, this.graph.width*this.size, this.graph.height*this.size);
                }
            }
            ctx.restore();
        }
        
    }
    //---------------------------------------------------------
    this.createPlane = function(width_, height_){
        this.createBox(width_,1,height_);
    }
    //---------------------------------------------------------
    this.createSphere = function(radius, detail){
        this.geometry = new THREE.SphereGeometry(radius, detail*1.5, detail);
        //this.material = new THREE.MeshNormalMaterial();
        if(this.material==null){
            this.material = new THREE.MeshNormalMaterial();
        }
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.visible = this.visible;
        this.mesh.updateMatrix();
        this.mesh.id_ = this;
        scene.add(this.mesh);
        this.model = true;
        this.graphic = false;
    }
    //---------------------------------------------------------
    this.createBox = function(width, height, depth){
        this.geometry = new THREE.CubeGeometry(width, height, depth, 1, 1, 1);
        //this.material = new THREE.MeshNormalMaterial();
        if(this.material==null){
            this.material = new THREE.MeshNormalMaterial();
        }
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.visible = this.visible;
        this.mesh.updateMatrix();
        this.mesh.id_ = this;
        scene.add(this.mesh);
        this.model = true;
        this.graphic = false;
    }
    //---------------------------------------------------------
    this.createCylinder = function(r_top, r_bot, height, detail, opened){
        this.geometry = new THREE.CylinderGeometry(r_top, r_bot, height, detail, 1, opened);
        //this.material = new THREE.MeshNormalMaterial();
        if(this.material==null){
            this.material = new THREE.MeshNormalMaterial();
        }
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.visible = this.visible;
        this.mesh.updateMatrix();
        this.mesh.id_ = this;
        scene.add(this.mesh);
        this.model = true;
        this.graphic = false;
    }
    //---------------------------------------------------------
    this.createTorus = function(radius, weight, detail){
        this.geometry = new THREE.TorusGeometry(radius, weight, detail*1.5, detail);
        //this.material = new THREE.MeshNormalMaterial();
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.visible = this.visible;
        this.mesh.updateMatrix();
        this.mesh.id_ = this;
        scene.add(this.mesh);
        this.model = true;
        this.graphic = false;
    }
    //---------------------------------------------------------
    this.createSphere = function(radius){
        this.radius = radius;
        this.geometry = new THREE.IcosahedronGeometry(radius, 1);
        //this.material = new THREE.MeshNormalMaterial();
        if(this.material==null){
            this.material = new THREE.MeshNormalMaterial();
        }
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.visible = this.visible;
        this.mesh.updateMatrix();
        this.mesh.id_ = this;
        scene.add(this.mesh);
        this.model = true;
        this.graphic = false;
    }
    //---------------------------------------------------------
    this.createMaterial = function(shaderType, col){
        switch(shaderType){
            case FLAT:
                this.material = new THREE.MeshNormalMaterial({shading: THREE.FlatShading});
                break;
            case SMOOTH:
                this.material = new THREE.MeshNormalMaterial({shading: THREE.SmoothShading});
                break;
            case WIRED:
                this.material = new THREE.MeshBasicMaterial({color: 0x000000, wireframe: true});
                break;
            case DEPTH:
                this.material = new THREE.MeshDepthMaterial();
                break;
            case PHONG:
                this.material = new THREE.MeshPhongMaterial({color: col});
                break;
            case LAMBERT:
                this.material = new THREE.MeshLambertMaterial({color: col});
                break;
            case TEXTURED:
                var texture = new THREE.Texture( col );
                texture.needsUpdate = true;
                this.material = new THREE.MeshPhongMaterial  ({
                                                    map: texture,
                                                    specular: 0xffffff,
                                                    shininess: 30
                                                });
                break;
        }
        
    }
    //---------------------------------------------------------
    // mover el punto de traslación del modelo..
    this.setCenter = function(x, y, z){
        if(this.model){
            this.geometry.applyMatrix( new THREE.Matrix4().makeTranslation(x, y, z) );
        }
        if(this.graphic){
            this.cx = -x;
            this.cy = -y;
        }
    }
    //---------------------------------------------------------
    this.worldToScreen = function() {
        var position = new THREE.Vector3();
        position.x = this.x;
        position.y = this.y;
        position.z = this.z;
        var vector = position.project(camera);
        vector.x = (vector.x + 1)/2 * width;
        vector.y = -(vector.y - 1)/2 * height;
        return vector;
    }
    //---------------------------------------------------------
    this.setGraph = function(graph){
        this.graph = graph;
        this.model = false;
        this.graphic = true;
        this.setCenter(this.size*this.graph.width/2, this.size*this.graph.height/2);
    }
    //---------------------------------------------------------
    this.addModel = function(m){
        var tmp_mod = THREE.SkeletonUtils.clone( m );
        tmp_mod.animations = m.animations;
        tmp_mod.id_ = this;
        tmp_mod.visible = false;
        var pos = this.models.push(tmp_mod);
        scene.add(tmp_mod);
    }
    //---------------------------------------------------------
    this.setModel = function(model_index){
        this.model_index = model_index;
        this.model = true;
        this.graphic = false;
        for(var i=0; i<this.models.length; i++){
            this.models[i].visible = false;
        }
        this.models[model_index].visible = this.visible;
        this.mesh = this.models[model_index];
        this.animation_mixer = new THREE.AnimationMixer( this.mesh );
        this.draw();    // para update de las propiedades del model..
    }
    //---------------------------------------------------------
    this.freeModels = function(m){
        this.model = false;
        for(var i=0; i<this.models.length; i++){
            scene.remove( this.models[i] );
        }
        this.animation_mixer = undefined;
    }
    //---------------------------------------------------------
    this.getAnimation = function(model_index, animation_index){
        var anima = this.animation_mixer.clipAction(this.models[model_index].animations[animation_index]);
        return anima;
    }
    //---------------------------------------------------------
    this.getAnimations = function(model_index){
        if(this.models[model_index].animations){
            return this.models[model_index].animations.length;
        }else{
            return -1;
        }
    }
    //---------------------------------------------------------
    this.frame = function (){
        
    }
    //---------------------------------------------------------
    this.advance = function (dist, angle=this.angle){
        if(this.graphic){
            this.x = this.x + dist * Math.sin(radians(angle));
            this.y = this.y + dist * Math.cos(radians(angle));
        }else{
            console.log("WARNING: attempt to use Advance() without graph.. ");
        }
    }
    //---------------------------------------------------------
    this.getDist = function (x, y, z){
        if(this.model){
            return Math.sqrt((x-this.x)*(x-this.x) + (y-this.y)*(y-this.y) + (z-this.z)*(z-this.z));
        }else{
            return Math.sqrt((x-this.x)*(x-this.x) + (y-this.y)*(y-this.y));
        }
    }
    //---------------------------------------------------------
    this.getAngle = function(bx, by){
        return -degrees(Math.atan2( by-this.y, bx-this.x ));
    }
    //---------------------------------------------------------
    this.advanceVector = function(x_, y_, dist, angle){
        x_ = x_ + dist * Math.sin(radians(angle));
        y_ = y_ + dist * Math.cos(radians(angle));
        return {x:x_, y:y_};
    }
    //---------------------------------------------------------
    this.finalize = function (){
        // eliminar la peticion de busqueda de toco suelo del array general..
        for(var i=0; i<_3div_requestIsGrounded.length; i++){
            if(_3div_requestIsGrounded[i] === this.body){
                _3div_requestIsGrounded.splice(i, 1);
            }
        }
        
        // eliminar los modelos del proceso..
        if(this.model){
            for(var i=0; i<this.models.length; i++)
            scene.remove(this.models[i]);
        }
        
        // eliminar la primitiva 3d del proceso..
        if(this.mesh !== undefined){
            scene.remove(this.mesh);
        }
        
        // ..
        if(this.graphic){
           
        }
        
        // eliminar el body del proceso..
        if(this.body !== undefined){
            world.remove(this.body);
        }
    }
    //---------------------------------------------------------
    this.collisionMouse = function (){
        var xmin = this.x-(this.graph.width/2)*this.size;
        var xmax = this.x+(this.graph.width/2)*this.size;
        var ymin = this.y-(this.graph.height/2)*this.size;
        var ymax = this.y+(this.graph.height/2)*this.size;
        for (var i=0; i<mouse.touches.length; i++) {
            var touch = mouse.touches[i];
            var x = (touch.clientX * width  ) / window.innerWidth; 
            var y = (touch.clientY * height ) / window.innerHeight;
            if(x>xmin && x<xmax && y>ymin && y<ymax){
                return true;
            }
        }
        if(mouse.x>xmin && mouse.x<xmax && mouse.y>ymin && mouse.y<ymax){
                return true;
        }
        return false;
    }
    //---------------------------------------------------------
    this.collision = function(other){
        return false;
    }
    //---------------------------------------------------------
    this.collisionType = function (type){
        return false;
    }
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------P H I S Y C S   M E T H O D S ! ! !-------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    this.destroyBody = function(){
        if(this.body){
            this.physic = false;
            world.remove(this.body);
            this.body = undefined;
        }
    }
    //---------------------------------------------------------
    this.createBody = function(tipo){
        this.draw();    // update rotation position scale of mesh..
        this.physic = true;
        var width_;
        var height_;
        var depth_;
        var radius_;
        switch(tipo){
            
                
            // BOX TYPE..
            case TYPE_BOX:
                if(this.sizex!=1 || this.sizey!=1 || this.sizez!=1){
                    width_  = this.mesh.geometry.parameters.width  * this.sizex;
                    height_ = this.mesh.geometry.parameters.height * this.sizey;
                    depth_  = this.mesh.geometry.parameters.depth  * this.sizez;
                }else{
                    width_  = this.mesh.geometry.parameters.width  * this.size;
                    height_ = this.mesh.geometry.parameters.height * this.size;
                    depth_  = this.mesh.geometry.parameters.depth  * this.size;
                }
                var shape = new CANNON.Box(new CANNON.Vec3(width_/2,height_/2,depth_/2));
                var masa = (width_*height_*depth_)/1000;
                this.body = new CANNON.Body({
                    mass: masa
                });
                this.body.addShape(shape);
                this.body.angularVelocity.set(0,0,0);
                this.body.force.set(0,0,0);
                this.body.angularDamping = 0.5;
                this.body.fixedRotation = false;
                
                this.body.quaternion.copy(this.mesh.quaternion);
                this.body.position.copy(this.mesh.position);
                
                world.addBody(this.body);
                break;
                
                
            // SPHERE TYPE..
            case TYPE_SPHERE:
                if(this.sizex!=1 || this.sizey!=1 || this.sizez!=1){
                    radius_  = this.radius * this.size;
                    console.log("Warning!, only nor sizex, sizey allowed..");
                    if(radius_===0){
                        console.log("Warning!, radius = 0.. createSphere() ??");
                        radius_ = 1;
                    }
                }else{
                    radius_  = this.radius * this.size;
                    if(radius_===0){
                        console.log("Warning!, radius = 0.. createSphere() ??");
                        radius_ = 1;
                    }
                }
                var shape = new CANNON.Sphere(radius_);
                var masa = ((4/3)*Math.PI*radius_*radius_*radius_)/1000;
                this.body = new CANNON.Body({
                    mass: masa
                });
                this.body.addShape(shape);
                this.body.angularVelocity.set(0,0,0);
                this.body.force.set(0,0,0);
                this.body.angularDamping = 0.5;
                this.body.fixedRotation = false;
                
                this.body.quaternion.copy(this.mesh.quaternion);
                this.body.position.copy(this.mesh.position);
                
                world.addBody(this.body);
                break;
            
                
            // PLANE TYPE..
            case TYPE_PLANE:
                //var groundShape = new CANNON.Plane();
                //var groundBody = new CANNON.Body({ mass: 0, shape: groundShape });
                //world.add(groundBody);
                
                if(this.sizex!=1 || this.sizey!=1 || this.sizez!=1){
                    width_  = this.mesh.geometry.parameters.width  * this.sizex;
                    height_ = 1;
                    depth_  = this.mesh.geometry.parameters.depth  * this.sizez;
                }else{
                    width_  = this.mesh.geometry.parameters.width  * this.size;
                    height_ = 1;
                    depth_  = this.mesh.geometry.parameters.depth  * this.size;
                }
                var shape = new CANNON.Box(new CANNON.Vec3(width_/2,height_,depth_/2));
                var masa = 0;
                this.body = new CANNON.Body({
                    mass: masa
                });
                this.body.addShape(shape);
                this.body.angularVelocity.set(0,0,0);
                this.body.force.set(0,0,0);
                this.body.angularDamping = 0.5;
                this.body.fixedRotation = false;
                
                this.body.quaternion.copy(this.mesh.quaternion);
                this.body.position.copy(this.mesh.position);
                
                world.addBody(this.body);
                break;
        }
    }
    //---------------------------------------------------------
    this.addImpulse = function(imp_){
        // Add an impulse to the center
        this.body.applyImpulse(imp_,this.body.position);
    }
    //---------------------------------------------------------
    this.addVx = function(imp_x){
        // Add an impulse to the center
        var impulse = new CANNON.Vec3(imp_x,0,0);
        this.body.applyImpulse(impulse,this.body.position);
    }
    //---------------------------------------------------------
    this.addVy = function(imp_y){
        // Add an impulse to the center
        var impulse = new CANNON.Vec3(0,imp_y,0);
        this.body.applyImpulse(impulse,this.body.position);
    }
    //---------------------------------------------------------
    this.addVz = function(imp_z){
        // Add an impulse to the center
        var impulse = new CANNON.Vec3(0,0,imp_z);
        this.body.applyImpulse(impulse,this.body.position);
    }
    //---------------------------------------------------------
    this.brake = function(percent){
        // Add an inverted impulse to the center
        var f = new CANNON.Vec3(-this.body.velocity.x*percent/100000,
                                -this.body.velocity.y*percent/100000,
                                -this.body.velocity.z*percent/100000
                               );
        this.body.applyImpulse(f,this.body.position);
    }
    //---------------------------------------------------------
    this.setStatic = function(static){
        if(static===true){
            this.oldMass = this.body.mass;
            this.body.mass = 0;
            this.body.updateMassProperties();
            this.body.velocity.set(0,0,0); 
            this.body.angularVelocity.set(0,0,0);
        }else{
            this.body.mass = this.oldMass;
            this.body.updateMassProperties();
            //this.body.velocity.set(0,0,0);
            //this.body.angularVelocity.set(0,0,0);
        }
    }
    //---------------------------------------------------------
    this.addGroundControl = function(id){
        if(id!==undefined){
            _3div_requestIsGrounded.push(id.body);
        }else{
            _3div_requestIsGrounded.push(this.body);
        }
    }
    //---------------------------------------------------------
    this.removeGroundControl = function(id){
        if(id!==undefined){
            for(var i=0; i<_3div_requestIsGrounded.length; i++){
                if(_3div_requestIsGrounded[i] === id.body){
                    _3div_requestIsGrounded.splice(i, 1);
                }
            }
        }else{
            for(var i=0; i<_3div_requestIsGrounded.length; i++){
                if(_3div_requestIsGrounded[i] === this.body){
                    _3div_requestIsGrounded.splice(i, 1);
                }
            }
        }
    }
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
}
//---------------------------------------------------------------------------------
function screenDrawGraphic(img_, x, y, angle, sizeX, sizeY, alpha ) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(radians(angle));
    ctx.globalAlpha=alpha;
    ctx.drawImage(img_, -(img_.width/2)*sizeX, -(img_.height/2)*sizeY, img_.width*sizeX, img_.height*sizeY);
    ctx.restore();
}
//---------------------------------------------------------------------------------
function screenDrawText(fnt_, size, text, cod, x, y, color) {  
    ctx.save();
    ctx.font = size+"px arial";
    ctx.fillStyle = color;
    
    switch(cod){
        case RIGHT:
            ctx.textAlign = "left";
            break;
        case CENTER:
            ctx.textAlign = "center";
            break;
        case LEFT:
            ctx.textAlign = "right";
            break;
    }
    ctx.textBaseline = "middle"; 
    ctx.fillText(text, x, y);
    ctx.restore();
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function random(range){
    return Math.random() * range;
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function radians(angle){
    return angle * (Math.PI/180);
}
function degrees(angle){
    return angle * (180/Math.PI);
}
function int(number){
    return Math.floor(number);
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function raycast () {
// Step 1: Detect light helper
    //1. sets the mouse position with a coordinate system where the center
    //   of the screen is the origin
    raymouse.x = ( mouse.x / width ) * 2 - 1;
    raymouse.y = - ( mouse.y / height ) * 2 + 1;

    //2. set the picking ray from the camera position and mouse coordinates
    raycaster.setFromCamera( raymouse, camera );    

    //3. compute intersections (note the 2nd parameter)
    var intersects = raycaster.intersectObjects( scene.children, true );

    for ( var i = 0; i < intersects.length; i++ ) {
        //console.log( intersects[ i ].object );
        if(intersects[i].object.id_!=undefined){
            intersects[ i ].object.id_.mouseover = true;
            intersects[ i ].object.id_.mouseover_distance = intersects[ i ].distance;
        }else{
            intersects[ i ].object.parent.id_.mouseover = true;
            intersects[ i ].object.parent.id_.mouseover_distance = intersects[ i ].distance;
        }
        //console.log( intersects[ i ].object ); 

        /*
            An intersection has the following properties :
                - object : intersected object (THREE.Mesh)
                - distance : distance from camera to intersection (number)
                - face : intersected face (THREE.Face3)
                - faceIndex : intersected face index (number)
                - point : intersection point (THREE.Vector3)
                - uv : intersection point in the object's UV coordinates (THREE.Vector2)
        */
    }
// Step 2: Detect normal objects
    //1. sets the mouse position with a coordinate system where the center
    //   of the screen is the origin
    raymouse.x = ( mouse.x / width ) * 2 - 1;
    raymouse.y = - ( mouse.y / height ) * 2 + 1;

    //2. set the picking ray from the camera position and mouse coordinates
    raycaster.setFromCamera( raymouse, camera );    

    //3. compute intersections (no 2nd parameter true anymore)
    var intersects = raycaster.intersectObjects( scene.children );

    for ( var i = 0; i < intersects.length; i++ ) {
        //console.log( intersects[ i ] ); 
        
        /*
            An intersection has the following properties :
                - object : intersected object (THREE.Mesh)
                - distance : distance from camera to intersection (number)
                - face : intersected face (THREE.Face3)
                - faceIndex : intersected face index (number)
                - point : intersection point (THREE.Vector3)
                - uv : intersection point in the object's UV coordinates (THREE.Vector2)
        */
    }

}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
const _UP       = 38;
const _DOWN     = 40;
const _LEFT     = 37;
const _RIGHT    = 39;
const _ENTER    = 13;
const _ESC      = 27;
const _SPACE    = 32;
const _SHIFT    = 16;
const _BLOCK_SHIFT = 20;
const _TAB      = 9;
const _Q        = 81;
const _W        = 87;
const _E        = 69;
const _R        = 82;
const _T        = 84;
const _Y        = 89;
const _U        = 85;
const _I        = 73;
const _O        = 79;
const _P        = 80;
const _A        = 65;
const _S        = 83;
const _D        = 68;
const _F        = 70;
const _G        = 71;
const _H        = 72;
const _J        = 74;
const _K        = 75;
const _L        = 76;
const _Ñ        = 192;
const _Z        = 90;
const _X        = 88;
const _C        = 67;
const _V        = 86;
const _B        = 66;
const _N        = 78;
const _M        = 77;
const _COMA     = 188;
const _PUNTO    = 190;
const _GUION    = 189;
const _1        = 49;
const _2        = 50;
const _3        = 51;
const _4        = 52;
const _5        = 53;
const _6        = 54;
const _7        = 55;
const _8        = 56;
const _9        = 57;
const _0        = 48;


var keyboard_buffer = "";
var keys = [256];
document.onkeydown = function(e) {
    keys[e.keyCode] = true;
    if (e.keyCode === 8){
        keyboard_buffer = keyboard_buffer.slice(0, -1);
    }else{
        if(e.keyCode===16 || e.keyCode===222 || e.keyCode===13){    	// mayusculas dieresis enter..
            
        }else if(e.keyCode===46){   // tecla delete..
            keyboard_buffer = "";
        }else {
            keyboard_buffer += e.key;
        }
    }
};
document.onkeyup = function(e) {
    keys[e.keyCode] = false;
};
function key(keyCode){
    return keys[keyCode];
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
document.onmousemove = function(event){
    event.preventDefault();
    mouse.canvas_x = event.clientX;
    mouse.canvas_y = event.clientY;
}
//---------------------------------------------------------------------------------
document.onmousedown = function(event){
    event.preventDefault();
    switch(event.which){
        case 1:
            mouse.left = true;
            break;
        case 2:
           mouse.middle = true;
            break;
        case 3:
            mouse.right = true;
            break;
           
    }
    mouse.canvas_x = event.clientX;
    mouse.canvas_y = event.clientY;
}
//---------------------------------------------------------------------------------
document.onmouseup = function(event){
    event.preventDefault();
    switch(event.which){
        case 1:
            mouse.left = false;
            break;
        case 2:
           mouse.middle = false;
            break;
        case 3:
            mouse.right = false;
            break;
           
    }
    mouse.canvas_x = event.clientX;
    mouse.canvas_y = event.clientY;
}
//---------------------------------------------------------------------------------
function Mouse() {
    this.canvas_x = 0;
    this.canvas_y = 0;
    this.x = 0;
    this.y = 0;
    this.left = false;
    this.right = false;
    this.middle = false;
    this.oldX = 0;
    this.oldY = 0;
    this.wheelUp = false;
    this.wheelDown = false;
    this.wheel = 0;
    this.pos = new THREE.Vector3(0,0,0.996);
    this.touches = [];
    this.raycast = false;
    this.moved
    //---------------------------------------------------------
    this.frame = function () {
        if(this.oldX===this.x && this.oldY===this.y){
            this.moved = false;
        }else{
            this.moved = true;
        }
        this.oldX = this.x;
        this.oldY = this.y;
        this.x = (this.canvas_x  * width  ) / window.innerWidth; 
        this.y = (this.canvas_y * height ) / window.innerHeight;
        if(this.raycast){
           raycast();
        }
    }
    //---------------------------------------------------------
    //---------------------------------------------------------
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function loadImage(ima){
    return new THREE.ImageLoader().load( ima );
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function method (codeToExecute){
    //var tmpFunc = new Function(codeToExecute);
    //tmpFunc();
    window[codeToExecute]();
}
//---------------------------------------------------------------------------------
function str(number){
    return number.toString();
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
// rutina para seguir caminos prefabricados, gracias hokuto por la idea!
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------

class path{
    //----------------------------------------------
    constructor(){
        this.points = [];               // vector list of path..
        this.lastDist = 999999999999;   // last distance to next vector..
        this.vel = 3;                   // velocity of movement..
        this.angleMode = false;         // angle align of sprite..
        this.pos = 0;                   // actual point of path..
        this.fst = 0;                   // machine state of forward mode..
        this.flst = 0;                  // machine state of forward loop mode..
        this.rst = 0;                   // machine state of reverse mode..
        this.rlst = 0;                  // machine state of reverse loop mode..
    }
    //----------------------------------------------
    add(x, y){
        var vec = createVector(x, y);
        this.points.push(vec);
    }
    //----------------------------------------------
    length(){
        return this.points.length-1;
    }
    //----------------------------------------------
    setPoint(num){
        this.pos = num;
    }
    //----------------------------------------------
    setVelocity(vel){
        this.vel = vel;
    }
    //----------------------------------------------
    angleMode(angleMode){
        this.angleMode = angleMode;
    }
    //----------------------------------------------
    move(type_){
        switch(type_){
            case FORWARD:
                switch(this.fst){
                    case 0:
                        var angle = degrees(atan2(_id_actual_process_runing_.y - this.points[this.pos].y, _id_actual_process_runing_.x - this.points[this.pos].x ));
                        _id_actual_process_runing_.advance2(-this.vel, 360-angle);
                        var d = dist(_id_actual_process_runing_.x, _id_actual_process_runing_.y, this.points[this.pos].x, this.points[this.pos].y);
                        if(d <= this.lastDist){
                            this.lastDist = d;
                        } else{
                            if(_id_actual_process_runing_.body_created){
                                _id_actual_process_runing_.translate(this.points[this.pos].x, this.points[this.pos].y);
                            } else{
                                _id_actual_process_runing_.x = this.points[this.pos].x;
                                _id_actual_process_runing_.y = this.points[this.pos].y;
                            }
                            this.lastDist = 999999999999;
                            this.fst = 10;
                        }
                        return false;
                        break;
                    case 10:
                        if(this.pos+1 < this.points.length){
                            this.pos ++;
                            this.fst = 0;
                            return false;
                        } else{
                            return true;
                        }
                        break;
                }
                break;
            case FORWARD_LOOP:
                switch(this.flst){
                    case 0:
                        var angle = degrees(atan2(_id_actual_process_runing_.y - this.points[this.pos].y, _id_actual_process_runing_.x - this.points[this.pos].x ));
                        _id_actual_process_runing_.advance2(-this.vel, 360-angle);
                        var d = dist(_id_actual_process_runing_.x, _id_actual_process_runing_.y, this.points[this.pos].x, this.points[this.pos].y);
                        if(d <= this.lastDist){
                            this.lastDist = d;
                        } else{
                            if(_id_actual_process_runing_.body_created){
                                _id_actual_process_runing_.translate(this.points[this.pos].x, this.points[this.pos].y);
                            } else{
                                _id_actual_process_runing_.x = this.points[this.pos].x;
                                _id_actual_process_runing_.y = this.points[this.pos].y;
                            }
                            this.lastDist = 999999999999;
                            this.flst = 10;
                        }
                        return this.pos;
                        break;
                    case 10:
                        if(this.pos+1 < this.points.length){
                            this.pos ++;
                            this.flst = 0;
                        } else{
                            this.pos = 0;
                            this.flst = 0;
                        }
                        return this.pos;
                        break;
                }
                break;
            case REVERSE:
                switch(this.rst){
                    case 0:
                        var angle = degrees(atan2(_id_actual_process_runing_.y - this.points[this.pos].y, _id_actual_process_runing_.x - this.points[this.pos].x ));
                        _id_actual_process_runing_.advance2(-this.vel, 360-angle);
                        var d = dist(_id_actual_process_runing_.x, _id_actual_process_runing_.y, this.points[this.pos].x, this.points[this.pos].y);
                        if(d <= this.lastDist){
                            this.lastDist = d;
                        } else{
                            if(_id_actual_process_runing_.body_created){
                                _id_actual_process_runing_.translate(this.points[this.pos].x, this.points[this.pos].y);
                            } else{
                                _id_actual_process_runing_.x = this.points[this.pos].x;
                                _id_actual_process_runing_.y = this.points[this.pos].y;
                            }
                            this.lastDist = 999999999999;
                            this.rst = 10;
                        }
                        return false;
                        break;
                    case 10:
                        if(this.pos > 0){
                            this.pos --;
                            this.rst = 0;
                            return false;
                        } else{
                            return true;
                        }
                        break;
                }
                break;
            case REVERSE_LOOP:
                switch(this.rlst){
                    case 0:
                        var angle = degrees(atan2(_id_actual_process_runing_.y - this.points[this.pos].y, _id_actual_process_runing_.x - this.points[this.pos].x ));
                        _id_actual_process_runing_.advance2(-this.vel, 360-angle);
                        var d = dist(_id_actual_process_runing_.x, _id_actual_process_runing_.y, this.points[this.pos].x, this.points[this.pos].y);
                        if(d <= this.lastDist){
                            this.lastDist = d;
                        } else{
                            if(_id_actual_process_runing_.body_created){
                                _id_actual_process_runing_.translate(this.points[this.pos].x, this.points[this.pos].y);
                            } else{
                                _id_actual_process_runing_.x = this.points[this.pos].x;
                                _id_actual_process_runing_.y = this.points[this.pos].y;
                            }
                            this.lastDist = 999999999999;
                            this.rlst = 10;
                        }
                        return this.pos;
                        break;
                    case 10:
                        if(this.pos > 0){
                            this.pos --;
                            this.rlst = 0;
                        } else{
                            this.pos = this.points.length-1;
                            this.rlst = 0;
                        }
                        return this.pos;
                        break;
                }
                break;
        }
    }
    //----------------------------------------------
    //----------------------------------------------
}
//---------------------------------------------------------------------------------
function loadSound(file){
    return new WaudSound(file, { autoplay: false, loop: false, volume: 0.5, onerror: { } });
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function inputBox(default_text, x, y, w, h, pwdMode){
    var p = new process();
    p.st = 0;
    p.str = default_text;
    p.x = x;
    p.y = y;
    p.w = w;
    p.h = h;
    p.pwdMode = pwdMode;
    p.eventName = "";
    p.textSize = 14;
    p.textColor = "gray";
    p.textColor1 = "gray";
    p.textColor2 = "black";
    p.os = window.navigator.platform;
    p.g1 = newGraph(w, h, 255,255,255,255);
    p.g2 = newGraph(w+2, h+2, 0,0,0,255);
    
    p.frame = function(){
        switch(this.st){
            case 0:
                if(this.collisionMouse()){
                    screenDrawGraphic(this.g2, this.x+this.g1.width/2, this.y, 0, 1, 1, 255);
                    if(mouse.left && !lockui){
                        lockui = true;
                        this.st = 10;
                        this.textColor = this.textColor2;
                    }
                }
                screenDrawGraphic(this.g1, this.x+this.g1.width/2, this.y, 0, 1, 1, 255);
                if(this.pwdMode){
                    var pwdStr =  "";
                    ctx.font = this.textSize+"px arial";
                    var len = ctx.measureText(this.str).width-5;
                    while(ctx.measureText(pwdStr).width<len){
                        pwdStr += '*';
                    }
                    screenDrawText(null, this.textSize, pwdStr, RIGHT, this.x, this.y, this.textColor);
                }else{
                    screenDrawText(null, this.textSize, this.str, RIGHT, this.x, this.y, this.textColor);
                }
                break;
            case 10:
                screenDrawGraphic(this.g2, this.x+this.g1.width/2, this.y, 0, 1, 1, 255);
                screenDrawGraphic(this.g1, this.x+this.g1.width/2, this.y, 0, 1, 1, 255);
                if(this.pwdMode){
                    var pwdStr =  "";
                    ctx.font = this.textSize+"px arial";
                    var len = ctx.measureText(this.str).width-5;
                    while(ctx.measureText(pwdStr).width<len){
                        pwdStr += '*';
                    }
                    screenDrawText(null, this.textSize, pwdStr, RIGHT, this.x, this.y, this.textColor);
                }else{
                    screenDrawText(null, this.textSize, this.str, RIGHT, this.x, this.y, this.textColor);
                }
                if(!mouse.left){
                    
                    if(window.navigator.maxTouchPoints>1){
                        this.str = window.prompt("", this.str);
                        method(this.eventName);
                        lockui = false;
                        this.st = 0;
                    }else{
                        keyboard_buffer = this.str;
                        this.st = 20;
                    }
                    
                }
                break;
            case 20:
                screenDrawGraphic(this.g2, this.x+this.g1.width/2, this.y, 0, 1, 1, 255);
                screenDrawGraphic(this.g1, this.x+this.g1.width/2, this.y, 0, 1, 1, 255);
                
                if(this.pwdMode){
                    var pwdStr =  "";
                    ctx.font = this.textSize+"px arial";
                    var len = ctx.measureText(this.str).width-5;
                    while(ctx.measureText(pwdStr).width<len){
                        pwdStr += '*';
                    }
                    screenDrawText(null, this.textSize, pwdStr+(frameCount % 30 > 15 ? "_" : ""), RIGHT, this.x, this.y, this.textColor);
                }else{
                    screenDrawText(null, this.textSize, this.str+(frameCount % 30 > 15 ? "_" : ""), RIGHT, this.x, this.y, this.textColor);
                }
                
                if(this.textExcedsLimixBox()){
                    keyboard_buffer = keyboard_buffer.slice(0, -1);
                    this.str = keyboard_buffer;
                }else{
                    this.str = keyboard_buffer;
                }
                
                if(key(_ENTER) || (mouse.left&&!this.collisionMouse())){
                    this.st = 0;
                    lockui = false;
                    method(this.eventName);
                    this.textColor = this.textColor1;
                }
                break;
        }
    }
    
    p.collisionMouse = function(){
        var xmin = this.x;
        var xmax = this.x+this.w;
        var ymin = this.y-this.h/2;
        var ymax = this.y+this.h/2;
        if(mouse.x>xmin && mouse.x<xmax && mouse.y>ymin && mouse.y<ymax){
            return true;   
        }
        return false;
    }
    
    p.textExcedsLimixBox = function(){
        ctx.font = this.textSize+"px arial";
        var ancho = ctx.measureText(this.str).width;
        if(ancho>this.w-2){
            return true;
        }else{
            return false;
        }
    }
    
     p.setEvent = function (eventName){
        this.eventName = eventName;
    }
    
    return p;
}
//---------------------------------------------------------------------------------
function gButton(graph, x, y, size){
    if(size === undefined){
        size = 1;
    }
    var p = new process();
    p.st = 0;
    p.value = 0;
    p.img_ = graph;
    p.size = size;
    p.x = x;
    p.y = y;
    p.eventName = null;
    p.frame = function(){
        switch(this.st){
            case 0:
                if(this.collisionMouse()){
                    this.drawLighter();
                    if(mouse.left && !lockui){
                        lockui = true;
                        method(this.eventName);
                        this.st = 10;
                   }
                }else{
                    this.drawNormal();
                }
                break;
            case 10:
                this.drawLighter();
                if(!mouse.left){
                    lockui = false;
                    this.st = 0;
                }
                break;
            case 20:
                
                break;
        }
    }
    p.collisionMouse = function(){
        var xmin = this.x-(this.img_.width/2)*this.size;
        var xmax = this.x+(this.img_.width/2)*this.size;
        var ymin = this.y-(this.img_.height/2)*this.size;
        var ymax = this.y+(this.img_.height/2)*this.size;
        if(mouse.x>xmin && mouse.x<xmax && mouse.y>ymin && mouse.y<ymax){
            return true;   
        }
        return false;
    }
    
    
    p.drawNormal = function(){
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(radians(-this.angle));
        ctx.globalAlpha=1;
        ctx.drawImage(this.img_, -(this.img_.width/2)*size, -(this.img_.height/2)*size, this.img_.width*size, this.img_.height*size);
        ctx.restore();
    }
    
    p.drawLighter = function(){
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(radians(-this.angle));
        ctx.globalAlpha=1;
        ctx.drawImage(this.img_, -(this.img_.width/2)*size, -(this.img_.height/2)*size, this.img_.width*size, this.img_.height*size);
        ctx.globalAlpha = 0.2;
        //ctx.globalCompositeOperation = "destination-out";
        ctx.fillStyle = "white";
        ctx.fillRect(-(this.img_.width/2)*size, -(this.img_.height/2)*size, this.img_.width*this.size, this.img_.height*size);
        ctx.restore();
    }
    
    p.setEvent = function (eventName){
        this.eventName = eventName;
    }
    
    return p;
}
//---------------------------------------------------------------------------------
function tButton(str, x, y){
    var p = new process();
    p.st = 0;
    p.str = str;
    p.x = x;
    p.y = y;
    p.eventName = "";
    p.textSize = 14;
    p.textColor = "black";
    
    ctx.font = this.textSize+"px arial";
    var w = ctx.measureText(p.str).width + p.textSize*2;
    var h = p.textSize+2;
    
    p.w = w;
    p.h = h;
    
    p.g1 = newGraph(w, h, 255,255,255,255);
    p.g2 = newGraph(w+2, h+2, 0,0,0,255);
    
    p.frame = function(){
        switch(this.st){
            case 0:
                if(this.collisionMouse()){
                    screenDrawGraphic(this.g2, this.x, this.y, 0, 1, 1, 255);
                    if(mouse.left && !lockui){
                        lockui = true;
                        this.st = 10;
                    }
                }
                screenDrawGraphic(this.g1, this.x, this.y, 0, 1, 1, 255);
                screenDrawText(null, this.textSize, this.str, CENTER, this.x, this.y, this.textColor);
                break;
            case 10:
                screenDrawGraphic(this.g2, this.x, this.y, 0, 1, 1, 255);
                screenDrawGraphic(this.g1, this.x, this.y, 0, 1, 1, 255);
                screenDrawText(null, this.textSize, this.str, CENTER, this.x, this.y, this.textColor);
                if(!mouse.left){
                    lockui = false;
                    method(this.eventName);
                    this.st = 0;
                }
                break;
        }
    }
    
    p.collisionMouse = function(){
        var xmin = this.x-(this.g1.width/2)*this.size;
        var xmax = this.x+(this.g1.width/2)*this.size;
        var ymin = this.y-(this.g1.height/2)*this.size;
        var ymax = this.y+(this.g1.height/2)*this.size;
        if(mouse.x>xmin && mouse.x<xmax && mouse.y>ymin && mouse.y<ymax){
            return true;   
        }
        return false;
    }
    
    p.textExcedsLimixBox = function(){
        ctx.font = this.textSize+"px arial";
        var ancho = ctx.measureText(this.str).width;
        if(ancho>this.w-2){
            return true;
        }else{
            return false;
        }
    }
    
     p.setEvent = function (eventName){
        this.eventName = eventName;
    }
    
    return p;
}
//---------------------------------------------------------------------------------
var load_model_security_flag = true;
function isSecureToLoadModel(){
    return load_model_security_flag;
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function loadModel2(filename, container){
    var obj = filename;
    var mtl = filename.substring(0, filename.length-4)+".mtl";
    console.info(obj, mtl);
    load_model_security_flag = false;
    var mtlLoader = new THREE.MTLLoader();
    mtlLoader.load( mtl, function( materials ) {
        materials.preload();
        var objLoader = new THREE.OBJLoader();
        objLoader.setMaterials( materials );
        objLoader.load( obj, function ( object ) {
        /*
        object.traverse( function ( child ) {
            if ( child instanceof THREE.Mesh ) {
                child.castShadow = true;
                child.receiveShadow = true;
            }   
        } );    
        */  
        //mod.push(object);
        container.push(object);
        load_model_security_flag = true;
      } );
    } );
}
//---------------------------------------------------------------------------------
function loadModel3(filename, container){
    
    load_model_security_flag = false;
    
    var loader = new THREE.FBXLoader();
		loader.load( filename, function ( object ) {
            //mixer = new THREE.AnimationMixer( object );
			//var action = mixer.clipAction( object.animations[ 0 ] );
			//action.play();
			object.traverse( function ( child ) {
				if ( child.isMesh ) {
					child.castShadow = true;
					child.receiveShadow = true;
				}
        } );
        //mod.push(object);
        container.push(object);
        load_model_security_flag = true;
        console.log(filename);
    } );
    
}
//---------------------------------------------------------------------------------
function loadModels(model_list){
    // variable global a false para indicar que no estan cargados los modelos..
    preloader_3Div_models = false;
    // creo sub proceso de carga..
    var p = new process();
    p.st = 0;       // estado interno..
    p.pos = 0;      // numero del ultimo modelo cargado..
    p.ready = false;
    p.dat = [];
    p.frame = function(){
        switch(this.st){
            case 0:
                if(isSecureToLoadModel()){              // si es seguro cargar un nuevo modelo..
                    if(this.pos < model_list.length){   // si quedan modelos por cargar..
                        this.st = 10;                   // salta al cargador..
                    }else{
                        this.ready = true;   // si no quedan modelos por cargar termina..
                        //signal(this, s_kill);           // fin..
                        console.log( 'Loading Complete!');
                        this.st = 30;
                    }
                }
                break;
            case 10:
                var extension =  model_list[this.pos].substring(model_list[this.pos].length-3, model_list[this.pos].length);
                if( extension == "obj" ){
                    loadModel2(model_list[this.pos], this.dat);
                }else if( extension == "fbx" ){
                    loadModel3(model_list[this.pos], this.dat);
                }
                
                this.pos++;                             // iterar una posicion en la lista de modelos..
                this.st = 0;                            // volver al estado inicial..
                break;
        }
    }
    
    p.isReady = function(){
        return p.ready;
    }
    
    p.get = function(){
        signal(p, s_kill);
        return p.dat;
    }
    
    return p;
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function loadImages(path){
    var p = new process();
    p.st = 0;
    p.folder = path;
    p.dat = [];
    p.numFiles = 99;
    p.pos = 0;
    p.name = "";
    p.loading = false;
    p.ready = false;
    p.frame = function(){
        //console.log(this.st);
        switch(this.st){
            
            case 0:
                
                if(this.pos<=this.numFiles){
                    if(this.pos<10){
                        this.name = "0" + str(this.pos) + ".png";
                    }else{
                        this.name = str(this.pos) + ".png";
                    }
                    this.loading = true;
                    this.st = 10;
                }else{
                    // FIN..
                    this.ready = true;
                }
                
                
                break;
            
            case 10:
                //console.log("loading.. "+this.folder+this.name);
                
                // instantiate a loader
                var loader = new THREE.TextureLoader();
                
                // load a resource
                this.dat[this.pos] = loader.load(
                    // resource URL
                    this.folder+this.name,

                    // onLoad callback
                    function ( texture ) {
                        // when the texture is loaded..
                        texture.name = "ready";
                    },

                    // onProgress callback currently not supported
                    undefined,

                    // onError callback
                    function(e){
                        p.pos = 100;
                        p.st = 0;
                    }
                );
                this.st = 20;
                
                break;
            
            case 20:
                
                if(this.dat[this.pos].name === "ready"){
                    this.dat[this.pos] = this.dat[this.pos].image;
                    this.pos++;
                    this.st = 0;
                }
                
                break;
        }
    }
    
    p.isReady = function(){
        return p.ready;
    }
    
    p.get = function(){
        signal(p, s_kill);
        return p.dat;
    }
    
    return p;
    
}
//---------------------------------------------------------------------------------
function loadSounds(path, num){
    var p = new process();
    p.st = 0;
    p.folder = path;
    p.dat = [];
    p.numFiles = num;
    p.pos = 0;
    p.name = "";
    p.loading = false;
    p.ready = false;
    p.frame = function(){
        //console.log(this.st);
        switch(this.st){
            
            case 0:
                
                if(this.pos<=this.numFiles){
                    if(this.pos<10){
                        this.name = "0" + str(this.pos);
                    }else{
                        this.name = str(this.pos);
                    }
                    this.loading = true;
                    this.st = 10;
                }else{
                    // FIN..
                    this.ready = true;
                }
                
                
                break;
            
            case 10:
                
                name = this.folder+this.name+".mp3";
                if(name != ""){
                    this.dat[this.pos] = new WaudSound(name, { autoplay: false, loop: false, volume: 0.5 });
                    this.st = 20;
                }else{
                    this.ready = true;
                    this.st = 30;
                }
                
                break;
            
            case 20:
                
                if(this.dat[this.pos].isReady()){
                    this.pos++;
                    this.st = 0;
                }
                
                break;
        }
    }
    
    p.isReady = function(){
        return p.ready;
    }
    
    p.get = function(){
        signal(p, s_kill);
        return p.dat;
    }
    
    return p;
    
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function fileExists(urlToFile) {
    var xhr = new XMLHttpRequest();
    try{
        xhr.open('GET', urlToFile, false);
        xhr.send();
    }catch(e){
        // nothing..
        console.log(e);
    }
     
    if (xhr.status == "404") {
        return false;
    } else {
        return true;
    }
}
//---------------------------------------------------------------------------------
function mapGetPixel(img, x, y){
    var offscreenCanvas = document.createElement('canvas');
    offscreenCanvas.style.display="none";
    offscreenCanvas.width  = img.width;
    offscreenCanvas.height = img.height;
    var ctx_ = offscreenCanvas.getContext('2d');
    ctx_.drawImage(img, 0, 0);
    return ctx_.getImageData(x, y, 1, 1).data;
}
//---------------------------------------------------------------------------------
function mapSetPixel(img, x, y, r,g,b,a){
    var cvs = document.createElement('canvas');
    cvs.style.display="none";
    cvs.width = img.width; 
    cvs.height = img.height;
    var ctx_ = cvs.getContext("2d");
    ctx_.drawImage(img,0,0,cvs.width,cvs.height);
    var pix = ctx_.getImageData(x,y,1,1);
    pix.data[0] = r;
    pix.data[1] = g;
    pix.data[2] = b;
    pix.data[3] = a;
    console.log(pix);
    ctx_.putImageData(pix, x,y);  // 0,0 is xy coordinates
    img.src = cvs.toDataURL();
}
//---------------------------------------------------------------------------------
function mapClear(img, r,g,b,a){
    var cvs = document.createElement('canvas');
    cvs.style.display="none";
    cvs.width = img.width; 
    cvs.height = img.height;
    var ctx = cvs.getContext("2d");
    ctx.beginPath();
    ctx.rect(0, 0, img.width, img.height);
    ctx.fillStyle = rgba(r,g,b,a);
    ctx.fill();
    img.src = cvs.toDataURL();
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function newGraph(w, h, r, g, b, a){
    var img_ = new Image(w, h);
    mapClear(img_, r,g,b,a);
    return img_;
}
//---------------------------------------------------------------------------------
function rgb(r,g,b) {
  r = r.toString(16);
  g = g.toString(16);
  b = b.toString(16);

  if (r.length == 1)
    r = "0" + r;
  if (g.length == 1)
    g = "0" + g;
  if (b.length == 1)
    b = "0" + b;

  return "#" + r + g + b;
}
//---------------------------------------------------------------------------------
function rgba(r,g,b,a) {
  r = r.toString(16);
  g = g.toString(16);
  b = b.toString(16);
  a = a.toString(16);
    
  if (r.length == 1)
    r = "0" + r;
  if (g.length == 1)
    g = "0" + g;
  if (b.length == 1)
    b = "0" + b;
  if (a.length == 1)
    a = "0" + a;
  
  return "#" + r + g + b + a;
}
//---------------------------------------------------------------------------------
function RGBToHex(r,g,b) {
  r = r.toString(16);
  g = g.toString(16);
  b = b.toString(16);

  if (r.length == 1)
    r = "0" + r;
  if (g.length == 1)
    g = "0" + g;
  if (b.length == 1)
    b = "0" + b;

  return "#" + r + g + b;
}
//---------------------------------------------------------------------------------
function RGBAToHex(r,g,b,a) {
  r = r.toString(16);
  g = g.toString(16);
  b = b.toString(16);
  a = Math.round(a * 255).toString(16);

  if (r.length == 1)
    r = "0" + r;
  if (g.length == 1)
    g = "0" + g;
  if (b.length == 1)
    b = "0" + b;
  if (a.length == 1)
    a = "0" + a;

  return "#" + r + g + b + a;
}
//---------------------------------------------------------------------------------
function arrayToHex(color){
    return RGBToHex( color[0], color[1], color[2] );
}
//---------------------------------------------------------------------------------
function putGraphic( dest_graph, dest_x, dest_y, source_graph, source_angle, source_scale, source_alpha ){
    if(source_angle==undefined){
        source_angle = 0;
    }
    if(source_scale==undefined){
        source_scale = 1;
    }
    if(source_alpha==undefined){
        source_alpha = 1;
    }
    var cvs = document.createElement('canvas');
    cvs.style.display="none";
    cvs.width = dest_graph.width; 
    cvs.height = dest_graph.height;
    var ctx_ = cvs.getContext("2d");
    ctx_.drawImage(dest_graph,0,0,cvs.width,cvs.height);
    
    ctx_.translate(dest_x, dest_y);
    ctx_.rotate(radians(source_angle));
    ctx_.globalAlpha=source_alpha;
    ctx_.drawImage(source_graph, -(source_graph.width/2)*source_scale, -(source_graph.height/2)*source_scale, source_graph.width*source_scale, source_graph.height*source_scale);
    
    dest_graph.src = cvs.toDataURL();
}
//---------------------------------------------------------------------------------
Vector2 = function( x, y ) {
	this.x = (x === undefined) ? 0 : x;
	this.y = (y === undefined) ? 0 : y;
}
//---------------------------------------------------------------------------------
soundPlayTimed = function(snd, millis){
    var p = new process();
    p.startTime = Date.now();
    p.millis = millis;
    p.snd = snd;
    p.frame = function(){
        if(Date.now()-this.startTime>this.millis){
            this.snd.play();
            signal(this, s_kill);
        }
    }
    return p;
}
//---------------------------------------------------------------------------------
class stringList{
    constructor(){
        this.data = [];
    }
    append(dato){
        this.data.push(dato);
    }
    get(index){
        return this.data[index];
    }
    size(){
        return this.data.length;
    }
}
//---------------------------------------------------------------------------------
function createTexturedPlane(img_, width_, height_, partSize){
    var numPartsWidth = Math.floor(width_/partSize);
    var numPartsHeight= Math.floor(height_/partSize);
    if(numPartsWidth<1){
        numPartsWidth = 1;
    }
    if(numPartsHeight<1){
        numPartsHeight = 1;
    }
    var geometry = new THREE.PlaneGeometry(width_, height_, numPartsWidth, numPartsHeight);
    
    var texture = new THREE.Texture( img_ );
    texture.needsUpdate = true;
    
    var material = new THREE.MeshPhongMaterial  ({
                                                    map: texture,
                                                    specular: 0xffffff,
                                                    shininess: 30
                                                });
    var mesh = new THREE.Mesh(geometry, material);
    mesh.visible = true;
    mesh.updateMatrix();
    scene.add(mesh);
    return mesh;
}
//---------------------------------------------------------------------------------
function joy(){
    var p = new process();
    p.ox = 0;
    p.oy = 0;
    p.modulo = 0;
    p.angulo = 0;
    p.maxmod = 40;
    p.st = 0;
    p.vec = {x:0, y:0};
    p.left = false;
    p.right = false;
    p.up = false;
    p.down = false;
    p.initialize = function(){
        this.pripority = -5000;
    }
    p.frame = function(){
        switch(this.st){
            case 0:
                if(mouse.left){
                    this.ox = mouse.x;
                    this.oy = mouse.y;
                    this.st = 10;
                }
                break;
            case 10:
                this.x = mouse.x;
                this.y = mouse.y;
                this.angulo = this.getAngle(this.ox, this.oy)+180;
                this.modulo = this.getDist(this.ox, this.oy)/this.maxmod;
                
                if(this.modulo>1){
                    this.modulo = 1;
                }
                
                this.vec = this.advanceVector(this.ox, this.oy, this.modulo*this.maxmod, this.angulo+90);
                this.drawJoy();
                
                if(!mouse.left){
                    this.modulo = 0;
                    this.st = 0;
                }
                
                
                // DIGITAL PAD..
                if(this.angulo<45 || this.angulo>315){
                    this.right = true;
                }else{
                    this.right = false;
                }
                
                if(this.angulo<225 && this.angulo>135){
                    this.left = true;
                }else{
                    this.left = false;
                }
                if(this.angulo<135 && this.angulo>45){
                    this.up = true;
                }else{
                    this.up = false;
                }
                if(this.angulo<315 && this.angulo>225){
                    this.down = true;
                }else{
                    this.down = false;
                }
                
                break;
        }
    }
    p.drawJoy = function(){
        ctx.save();
        ctx.globalAlpha=1;
        ctx.strokeStyle = "yellow";
        ctx.beginPath();
        ctx.ellipse(this.ox, this.oy, 50, 50, 0, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.restore();
        
        ctx.save();
        ctx.globalAlpha=1;
        ctx.fillStyle = "yellow";
        ctx.strokeStyle = "red";
        ctx.beginPath();
        ctx.ellipse(this.vec.x, this.vec.y, 10, 10, 0, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
        
    }
    
    return p;
    
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function deteremineScreenCoordinate(object) {
        var vector = new THREE.Vector3();
        vector.setFromMatrixPosition(object.matrixWorld);
        vector.project(camera);
        var width = window.innerWidth, height = window.innerHeight;
        var widthHalf = width / 2, heightHalf = height / 2;
        vector.x = ( vector.x * widthHalf ) + widthHalf;
        vector.y = -( vector.y * heightHalf ) + heightHalf;
        return vector;
}
//---------------------------------------------------------------------------------
class VideoBuffer{
    constructor(){
        this.canvas = document.createElement('canvas');
        this.canvas.style.display="none";
        this.canvas.width  = width;
        this.canvas.height = height;
        this.ctx = this.canvas.getContext('2d');
        this.ctx.globalAlpha = 1;
        this.ctx.lineWidth   = 5;
        this.ctx.fillStyle   = rgb(0,0,0);
        this.ctx.strokeStyle = rgb(0,0,0);
        
    }
    line(x0, y0, x1, y1){
        this.ctx.beginPath();
        this.ctx.moveTo(x0, y0);
        this.ctx.lineTo(x1, y1);
        this.ctx.stroke();
    }
    ellipse(x, y, radio){
        this.ctx.beginPath();
        this.ctx.arc(x, y, radio, 0, 2 * Math.PI, false);
        this.ctx.fill();
        this.ctx.stroke();
    }
    clear(){
        this.ctx.clearRect(0,0,this.canvas.width, this.canvas.height);
    }
}
//---------------------------------------------------------------------------------
function rotatePoint(pivot, point, angle) {
    // Rotate clockwise, angle in radians
	var x = Math.round((Math.cos(angle) * (point.x - pivot.x)) - (Math.sin(angle) * (point.y - pivot.y)) + pivot.x);
    var y = Math.round((Math.sin(angle) * (point.x - pivot.x)) + (Math.cos(angle) * (point.y - pivot.y)) + pivot.y);
    return { x: x, y: y };
}
//---------------------------------------------------------------------------------
function collision(p1, p2){
    
    var pivot = { x: p1.x, y: p1.y };               // centro del grafico 1..
    
    var scalex, scaley;                             // factor de escalado del grafico 1..
    if(p1.sizex!=1 || p1.sizey!=1){
        scalex = p1.sizex;
        scaley = p1.sizey;
    }else{
        scalex = scaley = p1.size;
    }
    
    var xmin = p1.x - p1.graph.width/2*scalex;      // limites del grafico 1..
    var xmax = p1.x + p1.graph.width/2*scalex;
    var ymin = p1.y - p1.graph.height/2*scaley;
    var ymax = p1.y + p1.graph.height/2*scaley;
        
    var a_ = { x: xmin, y: ymin };                   // vertices del grafico 1..
    var b_ = { x: xmax, y: ymin };
    var c_ = { x: xmin, y: ymax };
    var d_ = { x: xmax, y: ymax };
    
    var a = rotatePoint( pivot, a_, radians(-p1.angle) );
    var b = rotatePoint( pivot, b_, radians(-p1.angle) );
    var c = rotatePoint( pivot, c_, radians(-p1.angle) );
    var d = rotatePoint( pivot, d_, radians(-p1.angle) );
    
    
    
    
    
    return false;
}
//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------
function collisionVectorProceses( vec, proc ) {
	
    var circle = { x: vec.x, y: vec.y, radius: 1 };
    var rect;
    if(proc.sizex!=1 || proc.sizey!=1){
        rect = { x: proc.x, y: proc.y, width: proc.graph.width*proc.sizex, height: proc.graph.height*proc.sizey, rotation: radians(proc.angle) };
    }else{
        rect = { x: proc.x, y: proc.y, width: proc.graph.width*proc.size, height: proc.graph.height*proc.size, rotation: radians(proc.angle) };
    }
    
    
	var rectCenterX = rect.x;
	var rectCenterY = rect.y;

	var rectX = rectCenterX - rect.width / 2;
	var rectY = rectCenterY - rect.height / 2;

	var rectReferenceX = rectX;
	var rectReferenceY = rectY;
	
	// Rotate circle's center point back
	var unrotatedCircleX = Math.cos( rect.rotation ) * ( circle.x - rectCenterX ) - Math.sin( rect.rotation ) * ( circle.y - rectCenterY ) + rectCenterX;
	var unrotatedCircleY = Math.sin( rect.rotation ) * ( circle.x - rectCenterX ) + Math.cos( rect.rotation ) * ( circle.y - rectCenterY ) + rectCenterY;

	// Closest point in the rectangle to the center of circle rotated backwards(unrotated)
	var closestX, closestY;

	// Find the unrotated closest x point from center of unrotated circle
	if ( unrotatedCircleX < rectReferenceX ) {
		closestX = rectReferenceX;
	} else if ( unrotatedCircleX > rectReferenceX + rect.width ) {
		closestX = rectReferenceX + rect.width;
	} else {
		closestX = unrotatedCircleX;
	}
 
	// Find the unrotated closest y point from center of unrotated circle
	if ( unrotatedCircleY < rectReferenceY ) {
		closestY = rectReferenceY;
	} else if ( unrotatedCircleY > rectReferenceY + rect.height ) {
		closestY = rectReferenceY + rect.height;
	} else {
		closestY = unrotatedCircleY;
	}
 
	// Determine collision
	var collision = false;
	var distance = getDistance( unrotatedCircleX, unrotatedCircleY, closestX, closestY );
	
	if ( distance < circle.radius ) {
		collision = true;
	}
	else {
		collision = false;
	}

	return collision;
}

function getDistance( fromX, fromY, toX, toY ) {
	var dX = Math.abs( fromX - toX );
	var dY = Math.abs( fromY - toY );

	return Math.sqrt( ( dX * dX ) + ( dY * dY ) );
}

//---------------------------------------------------------------------------------
// Ported to JavaScript from 
// http://www.migapro.com/circle-and-rotated-rectangle-collision-detection/
//
// An example:
// var circle: { x: 20, y: 10, radius: 20 };
// var rect: { x: 30, y: 30, width: 100, height: 100, rotation: Math.PI / 2 };
// collideCircleWithRotatedRectangle( circle, rect );
// // returns true.
// 
//
// Please note:
// This code assumes that rect.x and rect.y are the CENTER coordinates
// of the rectangle. You may want to to change this.
// Also rotation values need to be in RADIANS.
function collisionMouse( proc ) {
	if(proc.model){
        if(mouse.raycast===false){
            console.log("collisionMouse() -> Mouse raycast is disabled. CollisionMouse needs enable to detect collisions with 3d objects.");
        }else{
            return proc.mouseover;
        }
    }
    if(!proc.graphic){
        return false;
    }
    var circle = { x: mouse.x, y: mouse.y, radius: 1 };
    var rect;
    if(proc.sizex!=1 || proc.sizey!=1){
        rect = { x: proc.x, y: proc.y, width: proc.graph.width*proc.sizex, height: proc.graph.height*proc.sizey, rotation: radians(proc.angle) };
    }else{
        rect = { x: proc.x, y: proc.y, width: proc.graph.width*proc.size, height: proc.graph.height*proc.size, rotation: radians(proc.angle) };
    }
        
    
    
	var rectCenterX = rect.x;
	var rectCenterY = rect.y;

	var rectX = rectCenterX - rect.width / 2;
	var rectY = rectCenterY - rect.height / 2;

	var rectReferenceX = rectX;
	var rectReferenceY = rectY;
	
	// Rotate circle's center point back
	var unrotatedCircleX = Math.cos( rect.rotation ) * ( circle.x - rectCenterX ) - Math.sin( rect.rotation ) * ( circle.y - rectCenterY ) + rectCenterX;
	var unrotatedCircleY = Math.sin( rect.rotation ) * ( circle.x - rectCenterX ) + Math.cos( rect.rotation ) * ( circle.y - rectCenterY ) + rectCenterY;

	// Closest point in the rectangle to the center of circle rotated backwards(unrotated)
	var closestX, closestY;

	// Find the unrotated closest x point from center of unrotated circle
	if ( unrotatedCircleX < rectReferenceX ) {
		closestX = rectReferenceX;
	} else if ( unrotatedCircleX > rectReferenceX + rect.width ) {
		closestX = rectReferenceX + rect.width;
	} else {
		closestX = unrotatedCircleX;
	}
 
	// Find the unrotated closest y point from center of unrotated circle
	if ( unrotatedCircleY < rectReferenceY ) {
		closestY = rectReferenceY;
	} else if ( unrotatedCircleY > rectReferenceY + rect.height ) {
		closestY = rectReferenceY + rect.height;
	} else {
		closestY = unrotatedCircleY;
	}
 
	// Determine collision
	var collision = false;
	var distance = getDistance( unrotatedCircleX, unrotatedCircleY, closestX, closestY );
	
	if ( distance < circle.radius ) {
		collision = true;
	}
	else {
		collision = false;
	}

	return collision;
}

function getDistance( fromX, fromY, toX, toY ) {
	var dX = Math.abs( fromX - toX );
	var dY = Math.abs( fromY - toY );

	return Math.sqrt( ( dX * dX ) + ( dY * dY ) );
}
//---------------------------------------------------------------------------------
function spotLight( target, color, intensidad, alcance, angulo ){
    var p = new process();
    p.light;
    p.target = target;
    p.off_x = 0;
    p.off_y = 0;
    p.off_z = 0;
    p.color = color;
    p.intensidad = intensidad;
    p.alcance = alcance;
    p.angulo = angulo;
            
    p.initialize = function(){
        this.light = new THREE.SpotLight( this.color, this.intensidad, this.alcance, radians(this.angulo) );
        this.light.position.set( this.target.x, this.target.y, this.target.z );
        scene.add( this.light );
    }
            
    p.frame = function(){
        var pos = new THREE.Vector3();
        pos.copy(this.target.body.position);
        pos.x += this.off_x;
        pos.y += this.off_y;
        pos.z += this.off_z;
        this.light.position.copy(pos);
    }
            
    p.setTarget = function(target){
        this.target = target;
    }
            
    p.setOffset = function(x, y, z){
        this.off_x = x;
        this.off_y = y;
        this.off_z = z;
    }
            
    return p;
}
//---------------------------------------------------------------------------------
function ambientLight( color, intensidad ){
    // LIGHT..
    var light = new THREE.AmbientLight( color, intensidad );
    scene.add( light );
    return light;
}
//---------------------------------------------------------------------------------
function simpleCamera(){
    var p = new process();
    p.st = 0;
    p.target;
    p.off_x;
    p.off_y;
    p.off_z;
    p.frame = function(){
        if(this.target !== undefined){
            var pos = new THREE.Vector3();
            pos.copy(this.target.body.position);
            pos.x += this.off_x;
            pos.y += this.off_y;
            pos.z += this.off_z;
            camera.position.copy(pos);
            camera.rotation.x = radians(-45);
        }
    }
    
    p.setTarget = function(target){
        this.target = target;
    }
    
    p.setOffset = function(x, y, z){
        this.off_x = x;
        this.off_y = y;
        this.off_z = z;
    }
    
    return p;
}
//---------------------------------------------------------------------------------